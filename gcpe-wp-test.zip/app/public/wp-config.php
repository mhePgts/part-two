<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '(=;v5LtxoxnJSJTN^0T7jU!dZK>Kjf!9QE?gsy3k{F3;~}tmh:[xN}ZS*oRFJ$S3' );
define( 'SECURE_AUTH_KEY',   '.PDh}uG)!%p[L.yI2)w+SH(TM-M}`,0s43hLt|Icdex0^k7pLqG@}?1C%KCb+_qY' );
define( 'LOGGED_IN_KEY',     'PQ4*r+5u=&h]Ymd:$&k;% 5%}[SA/l=gTfMw076FmiD|B-7SDBlE:[|*5Ke]-J[v' );
define( 'NONCE_KEY',         '~|EHpqZwXhSlcadSGU;2r8xoH}H1}0p9Ak9w`IXgh&O?cfb$uEpP^Q#lOVzsxIq6' );
define( 'AUTH_SALT',         'DHfwZoTpgPs}>Pgh5c>U=oU()I@ ==vYg5+~o/-v?@M/(3B c0q5nC0P4VY0EV=E' );
define( 'SECURE_AUTH_SALT',  ')O)Jl<|k2zrn]rzNgp+L=Yjs#(n#+!8/9gYWooI?}4^WE^X}KHhhb-Jk@bW;D(hk' );
define( 'LOGGED_IN_SALT',    ':k$L5N@+%j`YnVcb[|dB-=0vBKQ!Pi6;~LzSTr,oRXf|9%F<LuNy=%NO?TlpU9hm' );
define( 'NONCE_SALT',        'NBp5S|[yJ~+3x,0XX(.]`/45IkDnyNU Zk$hfglSj)c5Z%RzVHQnMPOD1M&_.cu/' );
define( 'WP_CACHE_KEY_SALT', '|gpmZ}w{DA/Z2,9K%lu4Idm/4evs*Zoahl+hr4~$1Mf%|%IyU&h*lg^>-VikS4,2' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
